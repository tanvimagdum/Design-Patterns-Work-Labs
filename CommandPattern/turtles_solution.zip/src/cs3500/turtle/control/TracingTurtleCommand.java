package cs3500.turtle.control;

import cs3500.turtle.tracingmodel.TracingTurtleModel;

/**
 * Created by blerner on 10/10/16.
 */
public interface TracingTurtleCommand {
  void go(TracingTurtleModel m);
}
