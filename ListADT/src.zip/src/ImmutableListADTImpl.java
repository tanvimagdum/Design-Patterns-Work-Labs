package listadt;

import java.util.function.Function;

/**
 * This is an implementation for an Immutable list.
 */

public class ImmutableListADTImpl<T> implements ImmutableListADT<T>{
  private ListADT<T> delegate;

  /**
   * Construct an ImmutableListADT object.
   */
  public ImmutableListADTImpl() {
    delegate = new ListADTImpl<>();
  }

  @Override
  public <R> CommonListADT<R> map(Function<T, R> converter) {
    return ImmutableListADTImpl.builderClass.build(delegate.map(converter));
    //return new ImmutableListADTImpl<>(delegate.map(converter));
  }

  @Override
  public int getSize() {
    return 0;
  }

  @Override
  public T get(int index) throws IllegalArgumentException {
    return null;
  }

  @Override
  public MutableListADT<T> getMutableList() {
    return null;
  }

  private void addBack(T b) {
    delegate.addBack(b);
  }

  /**
   * A builder class to build final Immutable list.
   * @param <T> the type of elements in this list
   */

  public static class builderClass<T> implements ImmutableListADT<T> {

    public static ImmutableListADT build(ListADT delegate) {
      ImmutableListADTImpl imm = new ImmutableListADTImpl<>();
      imm.addBack(delegate);
      return imm;
    }

  }

  public builderClass<T> getBuilder() {
    return new builderClass<T>();
  }
}
