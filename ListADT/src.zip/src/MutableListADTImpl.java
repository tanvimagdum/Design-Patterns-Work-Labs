package listadt;

import java.util.function.Function;

/**
 * This is an implementation for a Mutable list.
 */
public class MutableListADTImpl<T> implements MutableListADT<T> {


    @Override
    public void addFront(T b) {

    }

    @Override
    public void addBack(T b) {

    }

    @Override
    public void add(int index, T b) {

    }

    @Override
    public void remove(T b) {

    }

    @Override
    public <R> MutableListADTImpl<R> map(Function<T, R> converter) {
        return null;
    }

    @Override
    public int getSize() {
        return 0;
    }

    @Override
    public T get(int index) throws IllegalArgumentException {
        return null;
    }

    @Override
    public ImmutableListADT<T> getImmutableList() {
        return null;
    }
}
