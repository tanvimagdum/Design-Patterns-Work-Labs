package solution.listadt;

import java.util.Deque;
import java.util.LinkedList;
import java.util.function.Function;

/**
 * This is the implementation of a generic list. Specifically it implements
 * the listadt.ListADT interface
 */
public class ListADTImpl<T> implements ListADT<T> {

  Deque<Pair> TS = new LinkedList<>();
  Deque<Integer> RS = new LinkedList<>();
  public class Pair<S,T> {
    private String s;
    private GenericListADTNode<T> t;

    private Pair(String s, GenericListADTNode<T> t) {
      this.s = s;
      this.t = t;
    }
  }

  private GenericListADTNode<T> head;

  public ListADTImpl() {
    head = new GenericEmptyNode();
  }

  //a private constructor that is used internally (see map)
  private ListADTImpl(GenericListADTNode<T> head) {
    this.head = head;
  }

  @Override
  public void addFront(T b) {

    head = head.addFront(b);
  }

  @Override
  public void addBack(T b) {

    head = head.addBack(b);
  }

  @Override
  public void add(int index, T b) {

    head = head.add(index,b);
  }

  @Override
  public int getSize() {
    /*
    int acc = 0;
    GenericListADTNode<T> current = head;

    while (current instanceof GenericElementNode) {
      acc += 1;
      current = ((GenericElementNode<T>)current).getRest();
    }
    return acc;
     */

    int acc = 0;

    TS.push(new Pair<>("recur", head)); //start with the head
    while (!TS.isEmpty()) {
      Pair pNew = TS.pop();
      if (pNew.s.equals("recur")) {
        if (pNew.t instanceof GenericEmptyNode) {
          //simply process this node, no recursive call
          TS.push(new Pair<>("process", pNew.t));
        }
        if (pNew.t instanceof GenericElementNode) {
          //first make the recursive call, then process this node (add 1 to result)
          //added in reverse order so that they come out of stack in correct order
          TS.push(new Pair<>("process", pNew.t));
          TS.push(new Pair<>("recur", ((GenericElementNode<T>) pNew.t).getRest()));
        }
      }
      if (pNew.s.equals("process")) {
        if (pNew.t instanceof GenericEmptyNode) {
          //an empty node simply returns 0, as per above implementation
          RS.push(0);
        }
        if (pNew.t instanceof GenericElementNode) {
          //add 1 to the "last result", as per above implementation
          acc = RS.pop();
          RS.push( 1 + acc);
        }
      }
    }

    return RS.pop(); //the last thing remaining is the final result

  }

  @Override
  public void remove(T b) {

    head = head.remove(b);
  }

  @Override
  public T get(int index) throws IllegalArgumentException{
    if ((index>=0) && (index<getSize())) {
      return head.get(index);
    } else throw new IllegalArgumentException("Invalid index");

  }

  @Override
  public <R> ListADT<R> map(Function<T,R> converter) {
    return new ListADTImpl(head.map(converter));
  }

  @Override
  public String toString() {
    return "("+head.toString()+")";
  }
}

