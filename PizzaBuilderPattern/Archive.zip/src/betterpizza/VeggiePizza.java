package betterpizza;
import pizza.*;

import java.util.Map;

/**
 * This class represents a vegetarian pizza.
 */
public class VeggiePizza extends AlaCartePizza {

  /**
   * Create a veggie pizza with all vegetarian toppings, of the specified
   * size with the specified crust.
   * @param size the size of this pizza
   * @param crust the crust of this pizza
   */
  public VeggiePizza(Size size, Crust crust, Map<ToppingName,ToppingPortion> toppings) {
    super(size,crust,toppings);
  }

  public VeggiePizzaBuilder getVeggieBuilder() {
    return new VeggiePizzaBuilder();
  }
  public static class VeggiePizzaBuilder extends PizzaBuilder<VeggiePizzaBuilder> {
    public VeggiePizzaBuilder() {
      this.addTopping(ToppingName.Cheese, ToppingPortion.Full);
      this.addTopping(ToppingName.Sauce,ToppingPortion.Full);
      this.addTopping(ToppingName.BlackOlive,ToppingPortion.Full);
      this.addTopping(ToppingName.GreenPepper,ToppingPortion.Full);
      this.addTopping(ToppingName.Onion,ToppingPortion.Full);
      this.addTopping(ToppingName.Jalapeno,ToppingPortion.Full);
      this.addTopping(ToppingName.Tomato,ToppingPortion.Full);
    }

    @Override
    protected PizzaBuilder<VeggiePizzaBuilder> returnBuilder() {
      return this;
    }

    public VeggiePizza build() throws IllegalStateException {
      if (tempSize == null) {
        throw new IllegalStateException("Size not mentioned");
      }
      return new VeggiePizza(tempSize, tempCrust, tempToppings);
    }
  }
}
