package betterpizza;
import pizza.*;

import java.util.Map;

/**
 * This class represents a cheese pizza.
 */
public class CheesePizza extends AlaCartePizza {


  /**
   * Create a cheese pizza of the specified size with the specified crust.
   * @param size the size of this pizza
   * @param crust the crust of this pizza
   */
  public CheesePizza(Size size, Crust crust, Map<ToppingName,ToppingPortion> toppings) {
    super(size, crust,toppings);
  }

  public CheesePizzaBuilder getCheeseBuilder() { return new CheesePizzaBuilder(); }
  public static class CheesePizzaBuilder extends PizzaBuilder<CheesePizzaBuilder> {

    public CheesePizzaBuilder() {
      this.addTopping(ToppingName.Cheese, ToppingPortion.Full);
      this.addTopping(ToppingName.Sauce, ToppingPortion.Full);
    }

    @Override
    protected PizzaBuilder<CheesePizzaBuilder> returnBuilder() {
      return this;
    }

    public CheesePizza build() throws IllegalStateException {
      if (tempSize == null) {
        throw new IllegalStateException("Size not mentioned");
      }
      return new CheesePizza(tempSize, tempCrust, tempToppings);
    }

    public PizzaBuilder<CheesePizzaBuilder> noCheese() {
      this.addTopping(ToppingName.Cheese, ToppingPortion.Full);
      return returnBuilder();
    }

    public PizzaBuilder<CheesePizzaBuilder> leftHalfCheese() {
      this.addTopping(ToppingName.Cheese, ToppingPortion.LeftHalf);
      return returnBuilder();
    }

    public PizzaBuilder<CheesePizzaBuilder> rightHalfCheese() {
      this.addTopping(ToppingName.Cheese, ToppingPortion.RightHalf);
      return returnBuilder();
    }

  }
}
