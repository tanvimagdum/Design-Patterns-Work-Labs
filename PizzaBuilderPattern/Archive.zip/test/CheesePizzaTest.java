import betterpizza.CheesePizza;
import betterpizza.ObservablePizza;
import org.junit.Before;
import org.junit.Test;
import pizza.Crust;
import pizza.Size;
import pizza.ToppingName;
import pizza.ToppingPortion;

import static org.junit.Assert.*;

public class CheesePizzaTest {
  private ObservablePizza cheese;
  private ObservablePizza halfcheese;
  @Before
  public void setup() {
    cheese = new CheesePizza.CheesePizzaBuilder()
            .crust(Crust.Thin)
            .size(Size.Large)
            .build();
    halfcheese = new CheesePizza.CheesePizzaBuilder()
            .crust(Crust.Thin)
            .size(Size.Large)
            .leftHalfCheese()
            .build();
  }

  @Test
  public void testCost() {
    assertEquals(9,cheese.cost(),0.01);
    assertEquals(8.5,halfcheese.cost(),0.01);

  }
}